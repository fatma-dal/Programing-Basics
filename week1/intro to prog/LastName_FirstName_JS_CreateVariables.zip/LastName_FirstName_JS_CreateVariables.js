
var FirstNameOfTheRider ="Alice"
var LastNameOfTheRider = "tbdjs"
// should be at least 42 inches  
var Tall = 42
// should be grater than 10
 var Age = 10 
 // should return true 
  isHeARider = true 
